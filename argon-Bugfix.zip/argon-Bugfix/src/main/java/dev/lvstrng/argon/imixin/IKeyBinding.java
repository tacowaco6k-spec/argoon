package dev.lvstrng.argon.imixin;

public interface IKeyBinding {
	boolean isActuallyPressed();

	void resetPressed();
}
